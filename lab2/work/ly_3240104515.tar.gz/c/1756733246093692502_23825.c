This is a random .c file #3
